These FSRS presets are optimised for information-dense cards in the topics of maths or science.
They are best to be used for short-term memorisation (I typically start learning ~30 days before the module's exam). However, this can be modified depending on which preset you use!
- "Default" is my tried and tested preset, allowing for excellent memorisation after only 2 weeks.
- "Cram" is used when you have < 2 weeks to learn a deck - encourages fast and high short-term retention.
- "No Max Interval" is used for long-term retention, either for important preliminary concepts or for a deeper understanding of the content.